import path from 'path';
import { fileURLToPath } from 'url';

const filename = fileURLToPath(import.meta.url);
const dirname = path.dirname(filename);
import HtmlWebpackPlugin from 'html-webpack-plugin';
import webpack from 'webpack';
import dotenv from 'dotenv';

dotenv.config();

export default {
  entry: './src/index.jsx',

  output: {
    filename: 'bundle.js', // cache-busting filenames
    path: path.resolve(dirname, 'dist'),
    publicPath: '/',
    clean: true // wipe dist on each build
  },

  resolve: {
    extensions: ['.jsx', '.js', '.json'],

    alias: {
      react: path.resolve('./node_modules/react'),
      'react-dom': path.resolve('./node_modules/react-dom')
    }
  },

  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env', '@babel/preset-react']
          }
        }
      },
      {
        test: /\.scss$/,
        use: ['style-loader', 'css-loader', 'sass-loader']
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader']
      }
    ]
  },

  cache: {
    type: 'filesystem',
    buildDependencies: {
      config: [filename] // rebuild when config changes
    }
  },

  devServer: {
    static: {
      directory: path.join(dirname, 'public'),
      watch: true
    },
    compress: true,
    port: 1337,
    hot: true,
    open: true,
    headers: {
      'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
      Pragma: 'no-cache',
      Expires: '0',
      'Surrogate-Control': 'no-store'
    }
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: path.resolve(dirname, 'public/index.html') // your base file
    }),
    new webpack.DefinePlugin({
      'process.env': JSON.stringify(process.env) // inject all env vars
    })
  ]
};
