import React, { useState, useEffect, useRef } from 'react';
import { Modal, Image, Dropdown } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { Button, Box, Typography, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

import Confetti from 'react-confetti';

export default function WorkspaceModal({ workspaces, handleClose }) {
  const [selected, setSelected] = useState(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const [script, setScript] = useState(null);
  const iframeRef = useRef(null);

  const handleEmbed = async (id) => {
    try {
      const response = await fetch(`${process.env.API_BASE}/webflow/workspace/${id}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });

      // Check if the request actually resolves
      if (!response.ok) {
        const text = await response.text();
        throw new Error(`Server responded ${response.status}: ${text}`);
      }

      const data = await response.json();
      if (data) {
        const widgetScript = data.web_widget_script.replace(/\\n/g, '\n').replace(/\\"/g, '"');
        setScript(widgetScript);

        // 2. Inject into Webflow Designer as Embed node
        if (window.webflow && window.webflow.canvas) {
          await window.webflow.canvas.addNode({
            type: 'Embed',
            data: {
              code: widgetScript
            },
            parent: window.webflow.canvas.getSelectedNode()?.id || null // optional: attach to selected webflow designer element
          });
        }

        // 3. Show confetti success modal
        if (widgetScript) {
          setShowConfetti(true);
        }
      }
    } catch (error) {
      console.error('Failed to embed workspace:', error);
    }
  };

  useEffect(() => {
    if (iframeRef.current) {
      const doc = iframeRef.current.contentDocument || iframeRef.current.contentWindow.document;

      // Inject the script into iframe
      doc.open();
      doc.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="UTF-8" />
            <title>Preview</title>
            <style>
              html, body {
                margin: auto;
                padding: 0;
                width: 100%;
                height: 100%;
                display: flex;
                justify-content: center; /* or remove if you want left-aligned */
                align-items: center;
              }
              #ruut-container {
                width: 100% !important;
                height: 100% !important;
                margin: auto !important;
              }
            </style>
          </head>
          <body>
            <div id="ruut-container"></div>
            ${script}
            <script>
              // after widget script runs, try clicking launcher
              function tryClick() {
                var launcher = document.querySelector("button"); // adjust selector
                if (launcher) {
                  launcher.click();
                  console.log("✅ Widget auto-clicked");
                } else {
                 console.log("✅ Widget failed to autoclick");
                  setTimeout(tryClick, 0);
                }
              }
              tryClick();
            </script>
          </body>
        </html>
      `);
      doc.close();
    }
  }, [script, iframeRef, Confetti]);

  return (
    <Modal
      style={{ fontFamily: 'Raleway' }}
      show={true}
      onHide={handleClose}
      centered
      dialogClassName="modal-dark"
    >
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={4} padding={2}>
        <Box display="flex" alignItems="center" gap={1}>
          <Box component="img" src="/RUUT.png" alt="Ruut Logo" sx={{ width: 67, height: 24 }} />
        </Box>
        <IconButton
          onClick={() => (window.location.href = '/webflow/logout')}
          sx={{ color: 'white' }}
        >
          <CloseIcon />
        </IconButton>
      </Box>

      <Modal.Header closeButton className="w-100">
        <div className="bg-dark text-white d-flex flex-column mt-2">
          <Modal.Title>Select your workspace</Modal.Title>
          <small className="text-white mt-2">
            Don't have a workspace?{' '}
            <Link to="/create-workspace" className="text-info nav-links">
              Create One{' '}
            </Link>{' '}
          </small>
        </div>
      </Modal.Header>

      <Modal.Body>
        {workspaces.map((ws, i) => (
          <div
            key={i}
            className={`d-flex justify-content-between align-items-center p-3 mb-2 rounded cursor-pointer border ${
              selected === ws.id
                ? 'border-primary bg-primary text-white'
                : 'border-secondary text-light bg-workspace'
            }`}
            onClick={() => setSelected(ws.id)}
          >
            <span>{ws?.name}</span>

            {/* Toggle Switch */}
            <div className="form-check form-switch m-0">
              <div className="form-check form-switch m-0 custom-switch d-flex justify-content-between align-items-center gap-2">
                <input
                  style={{ width: 24, height: 12 }}
                  className="form-check-input cursor-pointer"
                  type="checkbox"
                  role="switch"
                  checked={selected === ws.id}
                  onChange={() => {
                    setSelected(selected === ws.id ? null : ws.id);
                  }}
                />
                {selected === ws.id && (
                  <Dropdown>
                    <Dropdown.Toggle
                      as="div"
                      bsPrefix="custom-toggle"
                      style={{ cursor: 'pointer', marginTop: 2 }}
                    >
                      <Image
                        src="/icons.png"
                        alt="Workspace"
                        width={12}
                        height={12}
                        style={{ cursor: 'pointer' }}
                      />
                    </Dropdown.Toggle>

                    <Dropdown.Menu>
                      <Dropdown.Item
                        as={Link}
                        to={{ pathname: `/customize/${ws.id}` }}
                        className="menu-workspace"
                      >
                        Customize Workspace
                      </Dropdown.Item>
                      <Dropdown.Item as={Link} to="/create-workspace" className="menu-workspace">
                        New Workspace
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                )}
              </div>
            </div>
          </div>
        ))}
      </Modal.Body>

      <Modal.Footer className="bg-dark text-white d-flex flex-column">
        <Button
          className="m-auto w-100"
          variant="primary"
          disabled={!selected}
          onClick={() => {
            handleEmbed(selected);
          }}
        >
          Proceed to embed
        </Button>
        <small className="text-white mt-4 m-auto">
          New workspace?{' '}
          <Link to="/create-workspace" className="text-info nav-links">
            Create One{' '}
          </Link>{' '}
        </small>
      </Modal.Footer>

      <Modal
        show={showConfetti}
        onHide={() => setShowConfetti(false)}
        aria-labelledby="modal-title"
        aria-describedby="modal-description"
      >
        <Box
          sx={{
            margin: '12.5% auto',
            width: '90%',
            maxWidth: 600,
            bgcolor: 'black', //background.paper',
            borderRadius: 2,
            color: 'white',
            boxShadow: 24,
            p: 4,
            textAlign: 'center',
            outline: 'none'
          }}
        >
          <Confetti
            style={{ margin: 'auto -100%' }}
            width={window.innerWidth}
            height={window.innerHeight}
          />

          <iframe
            ref={iframeRef}
            width="300"
            height="300"
            style={{
              display: 'block',
              margin: 'auto',
              backgroundColor: 'black',
              borderRadius: '100%'
            }}
            title="Preview Iframe"
          />

          <Typography id="modal-title" variant="h6" marginY={2} gutterBottom>
            Live Chat Embedded!
          </Typography>
          <Typography
            style={{ color: '#6f7994' }}
            id="modal-description"
            variant="body1"
            fontSize={14}
          >
            Your workspace is created and attached to your website. Once you launch your website,
            your live chat widget would be automatically active and working directly.
          </Typography>

          <Button
            style={{ backgroundColor: '#a450e9', color: 'white', width: '80%' }}
            sx={{ mt: 3 }}
            variant="contained"
            onClick={() => setShowConfetti(false)}
          >
            Close Widget
          </Button>
        </Box>
      </Modal>
    </Modal>
  );
}
