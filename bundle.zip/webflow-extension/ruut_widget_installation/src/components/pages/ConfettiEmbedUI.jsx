import React from 'react';
import { Button, Modal, Box, Dialog, DialogContent, Typography } from '@mui/material';
import Confetti from 'react-confetti';

export default function ConfettiEmbedUI({ showConfetti, setShowConfetti, iframeRef }) {
  return (
    <Modal
      open={showConfetti}
      onClose={() => setShowConfetti(false)}
      aria-labelledby="modal-title"
      aria-describedby="modal-description"
    >
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '90%',
          maxWidth: 600,
          bgcolor: 'background.paper',
          borderRadius: 2,
          boxShadow: 24,
          p: 4,
          textAlign: 'center',
          outline: 'none'
        }}
      >
        <Confetti width={window.innerWidth} height={window.innerHeight} />

        <iframe
          ref={iframeRef}
          width="100%"
          height="400"
          style={{
            display: 'block',
            margin: 'auto',
            backgroundColor: 'black'
          }}
          title="Preview Iframe"
        />

        <Typography id="modal-title" variant="h5" gutterBottom>
          🎉 Live Chat Embedded!
        </Typography>
        <Typography id="modal-description" variant="body1" color="textSecondary">
          Your workspace is attached to your website. Once you publish, your live chat widget will
          be automatically active and working directly.
        </Typography>

        <Button
          sx={{ mt: 3 }}
          variant="contained"
          color="primary"
          onClick={() => setShowConfetti(false)}
        >
          Done
        </Button>
      </Box>
    </Modal>
  );
}
