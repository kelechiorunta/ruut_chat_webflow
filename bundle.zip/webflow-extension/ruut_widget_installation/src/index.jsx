import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, HashRouter } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
// import { Toaster } from 'react-hot-toast';
import App from './App';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import './styles/custom.scss';
import 'react-toastify/dist/ReactToastify.css';

import { createTheme, ThemeProvider } from '@mui/material/styles';

const theme = createTheme({
  typography: {
    fontFamily: 'Raleway, Arial, sans-serif'
  }
});

// const Toaster = React.lazy(() => import('react-hot-toast').then((m) => ({ default: m.Toaster })));

const container = document.getElementById('root');
if (!container) {
  throw new Error('No #root element found in index.html');
}

const root = ReactDOM.createRoot(container);

root.render(
  <BrowserRouter>
    <ThemeProvider theme={theme}>
      <ToastContainer />
      <App />
    </ThemeProvider>
  </BrowserRouter>
);
